# io-list
Generic functions on lists with effects.
