v1.1 2018-07-09
---------------

- Fix a bug where `end defer` would not work when deferring in Type
- Make `Group` opaque to avoid having its contents being instantiated by e.g.
  `eauto`.

v1.0 2018-07-08
---------------

- First release
