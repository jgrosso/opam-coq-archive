# IO Effects
Coq system effects for extraction to [OCaml](http://ocaml.org/).

## Use
See the [io-system](https://github.com/clarus/io-system) project.
