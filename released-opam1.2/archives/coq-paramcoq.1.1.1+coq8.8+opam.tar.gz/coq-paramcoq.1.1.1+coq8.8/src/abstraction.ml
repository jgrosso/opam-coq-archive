
# 1 "src/abstraction.mlg"
 
(**************************************************************************)
(*                                                                        *)
(*     ParamCoq                                                           *)
(*     Copyright (C) 2012 - 2018                                          *)
(*                                                                        *)
(*     See the AUTHORS file for the list of contributors                  *)
(*                                                                        *)
(*   This file is distributed under the terms of the MIT License          *)
(*                                                                        *)
(**************************************************************************)



let __coq_plugin_name = "parametricity"
let _ = Mltop.add_known_module __coq_plugin_name

# 17 "src/abstraction.mlg"
 
open Ltac_plugin
open Feedback
open Stdarg
open Tacarg
open Parametricity
open Declare_translation
open Attributes


let () = Vernacextend.vernac_extend ~command:"SetParametricityTactic" ~classifier:(fun _ -> Vernacextend.classify_as_sideeff) ?entry:None 
         [(Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                     Vernacextend.TyTerminal ("Tactic", 
                                     Vernacextend.TyTerminal (":=", Vernacextend.TyNonTerminal (
                                                                    Extend.TUentry (Genarg.get_arg_tag wit_tactic), 
                                                                    Vernacextend.TyNil)))), 
         (let coqpp_body t locality ~st = let () = 
# 29 "src/abstraction.mlg"
                                                  
    Relations.set_parametricity_tactic
      (Locality.make_section_locality locality)
      (Tacintern.glob_tactic t) 
          in st in fun t ~atts ~st -> coqpp_body t
         (Attributes.parse locality atts) ~st), None))]

let () = Vernacextend.vernac_extend ~command:"ShowTable" ~classifier:(fun _ -> Vernacextend.classify_as_query) ?entry:None 
         [(Vernacextend.TyML (false, Vernacextend.TyTerminal ("Show", 
                                     Vernacextend.TyTerminal ("Parametricity", 
                                     Vernacextend.TyTerminal ("Table", 
                                     Vernacextend.TyNil))), (let coqpp_body () ~st = let () = 
                                                            
# 36 "src/abstraction.mlg"
                                         
  Relations.print_relations ()

                                                             in st in fun ~atts
                                                            ~st
                                                            -> coqpp_body (Attributes.unsupported_attributes atts) ~st), None))]

let () = Vernacextend.vernac_extend ~command:"ShowParametricityTactic" ~classifier:(fun _ -> Vernacextend.classify_as_query) ?entry:None 
         [(Vernacextend.TyML (false, Vernacextend.TyTerminal ("Show", 
                                     Vernacextend.TyTerminal ("Parametricity", 
                                     Vernacextend.TyTerminal ("Tactic", 
                                     Vernacextend.TyNil))), (let coqpp_body () ~st = let () = 
                                                            
# 42 "src/abstraction.mlg"
                                          
   Pp.(msg_info (str "Paramericity obligation tactic is " ++ Relations.print_parametricity_tactic ())) 
                                                             in st in fun ~atts
                                                            ~st
                                                            -> coqpp_body (Attributes.unsupported_attributes atts) ~st), None))]

let () = Vernacextend.vernac_extend ~command:"ParametricityDefined" ~classifier:(fun _ -> Vernacextend.classify_as_sideeff) ?entry:None 
         [(Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                     Vernacextend.TyTerminal ("Done", 
                                     Vernacextend.TyNil)), (let coqpp_body () ~st = let () = 
                                                           
# 47 "src/abstraction.mlg"
                                  
    parametricity_close_proof ()

                                                            in st in fun ~atts
                                                           ~st
                                                           -> coqpp_body (Attributes.unsupported_attributes atts) ~st), None))]

let () = Vernacextend.vernac_extend ~command:"AbstractionReference" ~classifier:(fun _ -> Vernacextend.classify_as_sideeff) ?entry:None 
         [(Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                     Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_ref), 
                                     Vernacextend.TyNil)), (let coqpp_body c
                                                           () ~st = let () = 
                                                           
# 54 "src/abstraction.mlg"
   
    command_reference default_arity (Constrintern.intern_reference c) None
  
                                                            in st in fun c
                                                           ~atts ~st
                                                           -> coqpp_body c
                                                           (Attributes.unsupported_attributes atts) ~st), None));
         (Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_reference), 
                                    Vernacextend.TyTerminal ("as", Vernacextend.TyNonTerminal (
                                                                   Extend.TUentry (Genarg.get_arg_tag wit_ident), 
                                                                   Vernacextend.TyNil)))), 
         (let coqpp_body c name () ~st = let () = 
# 58 "src/abstraction.mlg"
   
    command_reference default_arity (Constrintern.intern_reference c) (Some name)
  
          in st in fun c name ~atts ~st -> coqpp_body c name
         (Attributes.unsupported_attributes atts) ~st), None));
         (Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_reference), 
                                    Vernacextend.TyTerminal ("qualified", 
                                    Vernacextend.TyNil))), (let coqpp_body c
                                                           () ~st = let () = 
                                                           
# 62 "src/abstraction.mlg"
   
    command_reference ~fullname:true default_arity (Constrintern.intern_reference c) None
  
                                                            in st in fun c
                                                           ~atts ~st
                                                           -> coqpp_body c
                                                           (Attributes.unsupported_attributes atts) ~st), None));
         (Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_reference), 
                                    Vernacextend.TyTerminal ("arity", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_int), 
                                    Vernacextend.TyNil)))), (let coqpp_body c
                                                            arity
                                                            () ~st = let () = 
                                                            
# 66 "src/abstraction.mlg"
   
    command_reference arity (Constrintern.intern_reference c) None
  
                                                             in st in fun c
                                                            arity ~atts ~st
                                                            -> coqpp_body c
                                                            arity
                                                            (Attributes.unsupported_attributes atts) ~st), None));
         (Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_reference), 
                                    Vernacextend.TyTerminal ("arity", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_int), 
                                    Vernacextend.TyTerminal ("as", Vernacextend.TyNonTerminal (
                                                                   Extend.TUentry (Genarg.get_arg_tag wit_ident), 
                                                                   Vernacextend.TyNil)))))), 
         (let coqpp_body c arity name () ~st = let () = 
# 70 "src/abstraction.mlg"
   
    command_reference arity (Constrintern.intern_reference c) (Some name)
  
          in st in fun c arity name ~atts ~st -> coqpp_body c arity name
         (Attributes.unsupported_attributes atts) ~st), None));
         (Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_reference), 
                                    Vernacextend.TyTerminal ("arity", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_int), 
                                    Vernacextend.TyTerminal ("qualified", 
                                    Vernacextend.TyNil))))), (let coqpp_body c
                                                             arity
                                                             () ~st = let () = 
                                                             
# 74 "src/abstraction.mlg"
   
    command_reference ~fullname:true arity (Constrintern.intern_reference c) None
  
                                                              in st in fun c
                                                             arity ~atts ~st
                                                             -> coqpp_body c
                                                             arity
                                                             (Attributes.unsupported_attributes atts) ~st), None));
         (Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_reference), 
                                    Vernacextend.TyTerminal ("as", Vernacextend.TyNonTerminal (
                                                                   Extend.TUentry (Genarg.get_arg_tag wit_ident), 
                                                                   Vernacextend.TyTerminal ("arity", 
                                                                   Vernacextend.TyNonTerminal (
                                                                   Extend.TUentry (Genarg.get_arg_tag wit_integer), 
                                                                   Vernacextend.TyNil)))))), 
         (let coqpp_body c name arity () ~st = let () = 
# 78 "src/abstraction.mlg"
   
    command_reference arity (Constrintern.intern_reference c) (Some name)
  
          in st in fun c name arity ~atts ~st -> coqpp_body c name arity
         (Attributes.unsupported_attributes atts) ~st), None))]

let () = Vernacextend.vernac_extend ~command:"AbstractionRecursive" ~classifier:(fun _ -> Vernacextend.classify_as_sideeff) ?entry:None 
         [(Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                     Vernacextend.TyTerminal ("Recursive", 
                                     Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_reference), 
                                     Vernacextend.TyNil))), (let coqpp_body c
                                                            () ~st = let () = 
                                                            
# 85 "src/abstraction.mlg"
   
    command_reference_recursive default_arity (Constrintern.intern_reference c)
  
                                                             in st in fun c
                                                            ~atts ~st
                                                            -> coqpp_body c
                                                            (Attributes.unsupported_attributes atts) ~st), None));
         (Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                    Vernacextend.TyTerminal ("Recursive", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_reference), 
                                    Vernacextend.TyTerminal ("arity", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_integer), 
                                    Vernacextend.TyNil))))), (let coqpp_body c
                                                             arity
                                                             () ~st = let () = 
                                                             
# 89 "src/abstraction.mlg"
   
    command_reference_recursive arity (Constrintern.intern_reference c)
  
                                                              in st in fun c
                                                             arity ~atts ~st
                                                             -> coqpp_body c
                                                             arity
                                                             (Attributes.unsupported_attributes atts) ~st), None));
         (Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                    Vernacextend.TyTerminal ("Recursive", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_reference), 
                                    Vernacextend.TyTerminal ("qualified", 
                                    Vernacextend.TyNil)))), (let coqpp_body c
                                                            () ~st = let () = 
                                                            
# 93 "src/abstraction.mlg"
   
    command_reference_recursive ~fullname:true default_arity (Constrintern.intern_reference c)
  
                                                             in st in fun c
                                                            ~atts ~st
                                                            -> coqpp_body c
                                                            (Attributes.unsupported_attributes atts) ~st), None));
         (Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                    Vernacextend.TyTerminal ("Recursive", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_reference), 
                                    Vernacextend.TyTerminal ("arity", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_integer), 
                                    Vernacextend.TyTerminal ("qualified", 
                                    Vernacextend.TyNil)))))), (let coqpp_body c
                                                              arity
                                                              () ~st = let () = 
                                                              
# 97 "src/abstraction.mlg"
   
    command_reference_recursive ~fullname:true arity (Constrintern.intern_reference c)
  
                                                               in st in fun c
                                                              arity ~atts ~st
                                                              -> coqpp_body c
                                                              arity
                                                              (Attributes.unsupported_attributes atts) ~st), None))]

let () = Vernacextend.vernac_extend ~command:"Abstraction" ~classifier:(fun _ -> Vernacextend.classify_as_sideeff) ?entry:None 
         [(Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                     Vernacextend.TyTerminal ("Translation", 
                                     Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_constr), 
                                     Vernacextend.TyTerminal ("as", Vernacextend.TyNonTerminal (
                                                                    Extend.TUentry (Genarg.get_arg_tag wit_ident), 
                                                                    Vernacextend.TyNil))))), 
         (let coqpp_body c name () ~st = let () = 
# 104 "src/abstraction.mlg"
   
    translate_command default_arity c name
  
          in st in fun c name ~atts ~st -> coqpp_body c name
         (Attributes.unsupported_attributes atts) ~st), None));
         (Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                    Vernacextend.TyTerminal ("Translation", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_constr), 
                                    Vernacextend.TyTerminal ("as", Vernacextend.TyNonTerminal (
                                                                   Extend.TUentry (Genarg.get_arg_tag wit_ident), 
                                                                   Vernacextend.TyTerminal ("arity", 
                                                                   Vernacextend.TyNonTerminal (
                                                                   Extend.TUentry (Genarg.get_arg_tag wit_integer), 
                                                                   Vernacextend.TyNil))))))), 
         (let coqpp_body c name arity () ~st = let () = 
# 108 "src/abstraction.mlg"
   
    translate_command arity c name
  
          in st in fun c name arity ~atts ~st -> coqpp_body c name arity
         (Attributes.unsupported_attributes atts) ~st), None));
         (Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                    Vernacextend.TyTerminal ("Translation", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_constr), 
                                    Vernacextend.TyTerminal ("arity", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_integer), 
                                    Vernacextend.TyTerminal ("as", Vernacextend.TyNonTerminal (
                                                                   Extend.TUentry (Genarg.get_arg_tag wit_ident), 
                                                                   Vernacextend.TyNil))))))), 
         (let coqpp_body c arity name () ~st = let () = 
# 112 "src/abstraction.mlg"
   
    translate_command arity c name
  
          in st in fun c arity name ~atts ~st -> coqpp_body c arity name
         (Attributes.unsupported_attributes atts) ~st), None))]

let () = Vernacextend.vernac_extend ~command:"TranslateModule" ~classifier:(fun _ -> Vernacextend.classify_as_sideeff) ?entry:None 
         [(Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                     Vernacextend.TyTerminal ("Module", 
                                     Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_global), 
                                     Vernacextend.TyNil))), (let coqpp_body qid
                                                            () ~st = let () = 
                                                            
# 119 "src/abstraction.mlg"
   
    ignore (translate_module_command Parametricity.default_arity qid)
  
                                                             in st in fun qid
                                                            ~atts ~st
                                                            -> coqpp_body qid
                                                            (Attributes.unsupported_attributes atts) ~st), None));
         (Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                    Vernacextend.TyTerminal ("Module", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_global), 
                                    Vernacextend.TyTerminal ("as", Vernacextend.TyNonTerminal (
                                                                   Extend.TUentry (Genarg.get_arg_tag wit_ident), 
                                                                   Vernacextend.TyNil))))), 
         (let coqpp_body qid name () ~st = let () = 
# 123 "src/abstraction.mlg"
   
    ignore (translate_module_command ~name Parametricity.default_arity qid)
  
          in st in fun qid name ~atts ~st -> coqpp_body qid name
         (Attributes.unsupported_attributes atts) ~st), None));
         (Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                    Vernacextend.TyTerminal ("Module", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_global), 
                                    Vernacextend.TyTerminal ("arity", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_integer), 
                                    Vernacextend.TyNil))))), (let coqpp_body qid
                                                             arity
                                                             () ~st = let () = 
                                                             
# 127 "src/abstraction.mlg"
   
    ignore (translate_module_command arity qid)
  
                                                              in st in fun qid
                                                             arity ~atts ~st
                                                             -> coqpp_body qid
                                                             arity
                                                             (Attributes.unsupported_attributes atts) ~st), None));
         (Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                    Vernacextend.TyTerminal ("Module", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_global), 
                                    Vernacextend.TyTerminal ("as", Vernacextend.TyNonTerminal (
                                                                   Extend.TUentry (Genarg.get_arg_tag wit_ident), 
                                                                   Vernacextend.TyTerminal ("arity", 
                                                                   Vernacextend.TyNonTerminal (
                                                                   Extend.TUentry (Genarg.get_arg_tag wit_integer), 
                                                                   Vernacextend.TyNil))))))), 
         (let coqpp_body qid name arity () ~st = let () = 
# 131 "src/abstraction.mlg"
   
    ignore (translate_module_command ~name arity qid)
  
          in st in fun qid name arity ~atts ~st -> coqpp_body qid name arity
         (Attributes.unsupported_attributes atts) ~st), None));
         (Vernacextend.TyML (false, Vernacextend.TyTerminal ("Parametricity", 
                                    Vernacextend.TyTerminal ("Module", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_global), 
                                    Vernacextend.TyTerminal ("arity", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_integer), 
                                    Vernacextend.TyTerminal ("as", Vernacextend.TyNonTerminal (
                                                                   Extend.TUentry (Genarg.get_arg_tag wit_ident), 
                                                                   Vernacextend.TyNil))))))), 
         (let coqpp_body qid arity name () ~st = let () = 
# 135 "src/abstraction.mlg"
   
    ignore (translate_module_command ~name arity qid)
  
          in st in fun qid arity name ~atts ~st -> coqpp_body qid arity name
         (Attributes.unsupported_attributes atts) ~st), None))]

let () = Vernacextend.vernac_extend ~command:"Realizer" ~classifier:(fun _ -> Vernacextend.classify_as_sideeff) ?entry:None 
         [(Vernacextend.TyML (false, Vernacextend.TyTerminal ("Realizer", 
                                     Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_constr), 
                                     Vernacextend.TyTerminal ("as", Vernacextend.TyNonTerminal (
                                                                    Extend.TUentry (Genarg.get_arg_tag wit_ident), 
                                                                    Vernacextend.TyTerminal (":=", 
                                                                    Vernacextend.TyNonTerminal (
                                                                    Extend.TUentry (Genarg.get_arg_tag wit_constr), 
                                                                    Vernacextend.TyNil)))))), 
         (let coqpp_body c name t () ~st = let () = 
# 142 "src/abstraction.mlg"
   
    realizer_command Parametricity.default_arity (Some name) c t
  
          in st in fun c name t ~atts ~st -> coqpp_body c name t
         (Attributes.unsupported_attributes atts) ~st), None));
         (Vernacextend.TyML (false, Vernacextend.TyTerminal ("Realizer", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_constr), 
                                    Vernacextend.TyTerminal ("as", Vernacextend.TyNonTerminal (
                                                                   Extend.TUentry (Genarg.get_arg_tag wit_ident), 
                                                                   Vernacextend.TyTerminal ("arity", 
                                                                   Vernacextend.TyNonTerminal (
                                                                   Extend.TUentry (Genarg.get_arg_tag wit_integer), 
                                                                   Vernacextend.TyTerminal (":=", 
                                                                   Vernacextend.TyNonTerminal (
                                                                   Extend.TUentry (Genarg.get_arg_tag wit_constr), 
                                                                   Vernacextend.TyNil)))))))), 
         (let coqpp_body c name arity t () ~st = let () = 
# 146 "src/abstraction.mlg"
   
    realizer_command arity (Some name) c t
  
          in st in fun c name arity t ~atts ~st -> coqpp_body c name arity t
         (Attributes.unsupported_attributes atts) ~st), None));
         (Vernacextend.TyML (false, Vernacextend.TyTerminal ("Realizer", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_constr), 
                                    Vernacextend.TyTerminal ("arity", 
                                    Vernacextend.TyNonTerminal (Extend.TUentry (Genarg.get_arg_tag wit_integer), 
                                    Vernacextend.TyTerminal ("as", Vernacextend.TyNonTerminal (
                                                                   Extend.TUentry (Genarg.get_arg_tag wit_ident), 
                                                                   Vernacextend.TyTerminal (":=", 
                                                                   Vernacextend.TyNonTerminal (
                                                                   Extend.TUentry (Genarg.get_arg_tag wit_constr), 
                                                                   Vernacextend.TyNil)))))))), 
         (let coqpp_body c arity name t () ~st = let () = 
# 150 "src/abstraction.mlg"
   
    realizer_command arity (Some name) c t
  
          in st in fun c arity name t ~atts ~st -> coqpp_body c arity name t
         (Attributes.unsupported_attributes atts) ~st), None))]

