# IO
A library for effects in Coq.

## Install
Using OPAM for Coq:

    opam repo add coq-stable https://github.com/coq/repo-stable.git
    opam install coq:io

## Documentation
See the complete documentation online on [doc/io](http://clarus.github.io/doc/io/toc.html).
