% The TLC library
% Arthur Charguéraud, with contributions from others.
% CeCILL B license (the French equivalent of the BSD license).

Description
===========

TLC is a library for Coq based on classical logic and type classes.

Compilation
===========

To compile everything:

    make
    make install
