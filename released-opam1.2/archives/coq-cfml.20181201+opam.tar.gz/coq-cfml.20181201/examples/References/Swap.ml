
let swap i j =
   let t = !i in
   i := !j;
   j := t

