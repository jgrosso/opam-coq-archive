module type S =
  sig
    val capacity : int
  end
