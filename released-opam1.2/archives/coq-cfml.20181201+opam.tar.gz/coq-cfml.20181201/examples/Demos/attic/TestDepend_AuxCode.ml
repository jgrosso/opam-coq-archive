

type t = C | D

let f x = x
