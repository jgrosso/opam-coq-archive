coqide -R . SquiggleLazyEq $1 &>/dev/null &
