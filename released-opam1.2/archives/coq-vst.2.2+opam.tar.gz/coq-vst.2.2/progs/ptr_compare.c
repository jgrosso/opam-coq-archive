
int f (int *p, int *q) {
  return (p==q);
}
