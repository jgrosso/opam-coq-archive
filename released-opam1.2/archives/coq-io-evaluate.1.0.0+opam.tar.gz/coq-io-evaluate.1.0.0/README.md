# IO Eval
Generic functions to evaluate effects.
