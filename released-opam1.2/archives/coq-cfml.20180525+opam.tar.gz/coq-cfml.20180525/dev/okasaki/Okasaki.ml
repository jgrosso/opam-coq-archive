
exception EmptyStructure
exception BrokenInvariant
exception OutOfBound

let (!$) = Lazy.force

