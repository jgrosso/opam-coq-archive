# Iterable
Generic definition of iterators.