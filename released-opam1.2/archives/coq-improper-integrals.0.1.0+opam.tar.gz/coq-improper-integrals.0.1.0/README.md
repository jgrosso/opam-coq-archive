# improper integral extensions to coquelicot

Coquelicot already contains definitions of improper integrals.  This contains
a few extra theorems to make these integrals easier to use.

The main additions concern bounded convergence and correspondances with
proper integral.

Reminder: to generate a makefile type coq_makefile -f _CoqProject -o Makefile
