
#load "kernel.cmo";;
open Kernel;;
open Genlex;;
#load "checker.cmo";;
open Checker;;
