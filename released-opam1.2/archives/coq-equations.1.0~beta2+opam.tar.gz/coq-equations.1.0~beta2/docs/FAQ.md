---
layout: page
title: FAQ
permalink: /FAQ/
---

## Known limitations

# Version 1.0beta

It does not support mutual structural recursion (one can use a section
to define the bodies but it loses the elimination principle).

The ``dependent elimination`` tactic is in active development, and does
not have a ``dependent induction`` counterpart yet.

We don't try to automatically prove the completeness of the functions
 graph.
 
The ``Equations Logic`` command has been very lightly tested, and not
everything supports it yet.
