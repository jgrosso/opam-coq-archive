This directory contains pieces of code not ready for production, but that are
worth keeping to show how to write certain patterns.
