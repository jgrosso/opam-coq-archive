.. See zebibliography.html.rst for details

.. _bibliography:

.. bibliography:: biblio.bib
   :cited:
