#!/usr/bin/env sh

# Makefile generation
coq_makefile -f _CoqProject -o Makefile
