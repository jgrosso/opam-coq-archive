#!/usr/bin/env sh

coq_makefile -f Make -o Makefile