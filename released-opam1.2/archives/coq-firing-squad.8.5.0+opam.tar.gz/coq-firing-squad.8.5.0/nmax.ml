let r = ref Datatypes.O

let get () = !r 

let set n = r:= n
