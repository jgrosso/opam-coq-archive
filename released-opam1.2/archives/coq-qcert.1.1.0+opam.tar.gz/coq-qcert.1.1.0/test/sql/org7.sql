select count(*)
from employees
where age = 32
;
