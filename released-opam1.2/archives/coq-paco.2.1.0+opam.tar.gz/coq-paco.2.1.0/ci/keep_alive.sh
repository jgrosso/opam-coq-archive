#!/usr/bin/env bash
# Stolen from fiat-crypto: https://github.com/mit-plv/fiat-crypto/blob/78656baa06ed1daeb7ba90c2d429228516dc8475/etc/ci/keep_alive.sh

while [ 1 ]
do
    echo ""
    echo "Travis keep-alive spew"
    sleep 5m
done
