# GeoCoq
A formalization of geometry in Coq based on Tarski's axiom system

Details and installation instructions can be found :
http://geocoq.github.io/GeoCoq/

