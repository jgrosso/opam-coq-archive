# io-exception
Abstract your errors into exceptions.
