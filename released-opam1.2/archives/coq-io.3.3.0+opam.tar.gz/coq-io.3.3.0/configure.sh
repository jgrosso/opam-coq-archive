#!/bin/sh

coq_makefile -f Make -o Makefile -arg "-compat 8.4"
