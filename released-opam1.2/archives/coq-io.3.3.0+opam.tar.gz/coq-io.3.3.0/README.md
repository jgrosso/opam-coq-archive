# ![Logo](https://raw.githubusercontent.com/clarus/icons/master/megaphone-48.png) IO
> A library for effects in Coq.

## Install
Using [OPAM for Coq](coq.io/opam/):

    opam repo add coq-released https://coq.inria.fr/opam/released
    opam install coq-io

## Documentation
See the complete documentation online on [v3.1.0](http://coq-io.github.io/doc/io/3.1.0/toc.html).
