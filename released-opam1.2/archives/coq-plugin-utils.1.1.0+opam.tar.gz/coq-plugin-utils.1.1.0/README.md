coq-plugin-utils
================

Useful utility functions for writing Coq plugins

Install from OPAM
-----------------
Make sure you added the [Coq repository](coq.io/opam/):

    opam repo add coq-released https://coq.inria.fr/opam/released

and run:

    opam install coq-plugin-utils