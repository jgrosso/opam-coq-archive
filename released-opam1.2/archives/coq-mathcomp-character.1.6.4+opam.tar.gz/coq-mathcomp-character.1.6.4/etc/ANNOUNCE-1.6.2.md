# MathComp 1.6.3 released

We are proud to announce the immediate availability of the
Ssreflect proof language and the Mathematical Components library
version 1.6.3 for 8.5pl3, 8.6.1 and 8.7.0.

This minor release adds compatibility with Coq 8.7 and loses
compatilility with Coq 8.4.

Sources and Windows packages are available at:
  https://github.com/math-comp/math-comp/releases

Best regards,
-- 
The Mathematical Components team
