
exception HammerError of string
exception HammerFailure of string
