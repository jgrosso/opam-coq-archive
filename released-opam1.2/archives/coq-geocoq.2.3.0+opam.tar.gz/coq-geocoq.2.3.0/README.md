# GeoCoq
A formalization of geometry in Coq.

Details and installation instructions can be found :
http://geocoq.github.io/GeoCoq/

[![Build Status](https://travis-ci.org/GeoCoq/GeoCoq.svg?branch=master)](https://travis-ci.org/GeoCoq/GeoCoq)
