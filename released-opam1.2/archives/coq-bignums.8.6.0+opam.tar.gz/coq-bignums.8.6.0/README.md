
The BigNums Library
===================

Coq library of arbitrary large numbers.
Provides BigN, BigZ, BigQ that used to be part of Coq standard library.

TODO
----

  - Documentation
  - Add a Makefile in the tests/ directory

Authors
-------

Copyright INRIA 2007-2017.

Initial Code by Laurent Théry, Benjamin Grégoire, Arnaud Spiwack.
Many revisions by Evgeny Makarov and Pierre Letouzey.

License
-------

LGPL 2.1
