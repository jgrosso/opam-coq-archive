#!/bin/sh

cd doc
make
