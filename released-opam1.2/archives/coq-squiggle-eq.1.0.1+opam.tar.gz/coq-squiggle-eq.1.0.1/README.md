# SquiggleLazyEq

Installation:

`make`    
`sudo make install`
