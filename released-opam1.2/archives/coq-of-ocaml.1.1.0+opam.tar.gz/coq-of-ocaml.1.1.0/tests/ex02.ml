(** Tuples *)

let t0 = ()

let t1 = ('c', "one")

let t2 = (1, 2, 3, false, true)

let f x = (x, x)

let t3 = f 12
