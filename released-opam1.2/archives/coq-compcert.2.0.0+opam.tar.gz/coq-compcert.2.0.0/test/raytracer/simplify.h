/* Add bounding sphere info to the given object (recursively) */

void compute_bounding_spheres(struct object * obj);
