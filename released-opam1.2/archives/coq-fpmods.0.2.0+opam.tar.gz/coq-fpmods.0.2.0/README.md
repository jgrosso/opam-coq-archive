		      Finitely Presented Modules
======================================================================

Short Description
=================

We provide  two types  to represent the  abelian category  of finitely
presented modules that can be found in the fpmod file:

We  define  finitely presented  modules  and  morphisms between  them,
including the identity and zero morphisms, together with operations on
morphisms:   multiplication   (<i>i.e.</i>   composition),   addition,
negation,  kernel  and cokernel.  We  also  prove  that the  class  of
finitely presented modules together with the class of module morphisms
forms an abelian category.

- fmodule R for objects of the category
- 'Mor(M,N) for morphisms of the category
- 0, 1, phi + psi, - phi, phi ** psi
  are respectively the zero morphism, the identity (endo)morphism, the
  addition of morphisms, the negation of morphisms and the composition
  of morphism.
- kernel phi and coker phi are the kernel and cokernel of phi.


Files
=====

The files in the distribution are:

coherent - theory of (left) coherent rings

dvdring  -  theory of  rings  with  explicit divsibility  (dvd  rings,
            euclidean rings, Bézout rings, gcd rings and PIDs)

fpmod - finitely presented modules and proof that they form an abelian
        category

mxstructure  -   structures  of  matrices,  among   other  things  the
                 construction  of   diagonal  matrices  from   a  list
                 (diag_mx_seq)

ssrcomplements - complements to the SSReflect libraries

stronglydiscrete - theory of strongly discrete rings


REQUIREMENTS
============

Coq version >=8.4pl2
SSReflect >=1.4


License
=======

This library is provided under MIT license (see LICENSE file)