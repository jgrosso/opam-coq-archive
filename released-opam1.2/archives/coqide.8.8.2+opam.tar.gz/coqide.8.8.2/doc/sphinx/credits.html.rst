.. _credits:

-------
Credits
-------

.. include:: credits-contents.rst
