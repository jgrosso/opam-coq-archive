# Proxy
A proxy to interface concurrent Coq programs with the operating system.
