SELECT name
FROM employees
WHERE age = 32;
