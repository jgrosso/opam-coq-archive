# Not documented yet

This makefile generates files that translate all the modules in the standard library. 
It takes a lot of time. Oh, and also, it's still a bit buggy. 
