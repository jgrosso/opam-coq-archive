(** Polymophic function *)

let f x y = x

let n = f 12 3