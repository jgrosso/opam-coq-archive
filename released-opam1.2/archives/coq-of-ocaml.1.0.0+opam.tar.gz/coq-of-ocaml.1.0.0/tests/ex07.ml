(** Basic functions from Pervasives *)

let b = (false = true) || (() <> ()) && not true

let n1 = 1 + 2 * 3

let n2 = abs (- 1) + (+ 1) - 5 / 23 mod 4 * 3

let n3 = pred (succ 12)

let n4 = 5 land 7 lor 3 lxor 9

let n5 = 156 lsl 4 + 12 lsr 1

let s = "ghj" ^ "klm"

let c _ = char_of_int (int_of_char 'c' + 1)

let x = ignore 23

let p = fst (1, 2) + snd (3, 4)

let l = [1; 2] @ [3]

let y = (fun n -> n + 1) @@ 12
