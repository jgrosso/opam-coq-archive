# Plouffe
Computing Pi decimal using Plouffe Formula in Coq

## Install
Add the OPAM repository:

    opam repo add coq-released https://coq.inria.fr/opam/released

and run:

    opam install coq-plouffe
