Cybele
======

*A Coq plugin for simpler proofs by reflection or OCaml certificates.*

[http://cybele.gforge.inria.fr/](http://cybele.gforge.inria.fr/)

Requirements
------------

This plugin requires the latest trunk version of Coq.

Compilation
-----------

Before anything else, make sure that all the utilities of Coq are in
your path. Compile by typing:

    ./configure.sh
    make

Finally, install your plugin:

    make install

(as root if necessary).

Examples
--------

Go to test-suite/. You can try out each example doing a:

    ./configure.sh
    make
