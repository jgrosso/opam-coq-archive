The files of this directory are intented to follow the same scheme as those of the kernel directory of Coq's source code.
