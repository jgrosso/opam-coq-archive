(** Operators *)

let (+++) x y = x + y
let (~~) x = - x

let z = ~~ 12 +++ 14