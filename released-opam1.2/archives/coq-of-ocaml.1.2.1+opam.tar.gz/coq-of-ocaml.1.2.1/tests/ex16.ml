(** Type synonyms. *)

type t1 = string

type ('a, 'b) t2 = 'a * 'b
