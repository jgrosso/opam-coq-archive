(** Pre-defined types *)

let u = ()

let l1 = []

let l2 = [1]

let l3 = [1; 5; 7; 32; 15]

let o1 = None

let o2 = Some 12

let c = 'g'

let s1 = "bla"

let s2 = "\""
